<?php
include 'connection.php';

session_start();

if(isset($_POST['submit'])){
$email=$_POST['email'];
$pass=md5($_POST['password']);

//sql select statement//
$sql="SELECT * FROM tbl_users  WHERE `email`='$email' AND `password`='$pass' ";
$query=mysqli_query($conn,$sql);

$user_details = getData($sql,$conn);

if(sizeof($user_details)>0){

    session_start();
    $_SESSION['user_details'] = $user_details[0];
    $_SESSION['is_logged_in'] = true;
    if($_SESSION['user_details']['role_id']==3){
    	header('Location:User Module/home.php');
	}
	elseif ($_SESSION['user_details']['role_id']==2) {
		header('Location:Server Module/home.php');
	}
	elseif ($_SESSION['user_details']['role_id']==1) {
		header('Location:Admin Module/dashboard.php');
	}
}
else{
	$error[] = 'incorrect email or password!';
	header('Location:login.php');
 }
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <style>
    body{
    margin:0;
    padding: 0;
    background-image: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)), url(grocery.jpg);
}
body .reg h1{
    color: white;
    margin-top: 7%;
    margin-bottom: 3%;
}
body h2{
    color: white;
    margin-top: 3%;
    margin-bottom: 2%;
}
body .logins{
    color:white;
    text-align: center;
}
body .logins .form-btn{
    color:black;
    width: 17%;
    background-color: green;
}
form{
    color:white;
    text-align: center;
}
input[type=submit]{
    width: 17%;
    padding:5px;
    background-color: green;
    color:black
}
body .logins input[type=text]{
    color:black;
    text-align: center;
}
body .logins input[type=email]{
    color:black;
    text-align: center;
}
body .logins input[type=password]{
    color:black;
    text-align: center;
}
</style>
</head>
<body>
	<div class="reg" style="border-style: solid;border-width: 1px;">
   <h1 class="regiTitle" style="text-align: center">Login</h1>
   <form class="register" style="line-height: 30px;" action="login.php" method="post">
      <div class="logins">
	
	  <!-- <label for="surname">Surname:</label><br>
      <input type="text" class="input-box" name="surname" required><br><br>
      <label for="firstname">Firstname:</label><br>
      <input type="text" class="input-box" name="firstname" required><br><br> -->
      <label for="email">Input your email address:</label><br>
      <input type="email" class="register-input" placeholder="Email address" name="email" required><br><br>
      <label for="password">Input your password:</label><br>
      <input type="password" class="register-input" placeholder="password" name="password" required><br><br>
      <!-- <input type="submit" value="Enter Account" class="submit"> -->
	  <input type="submit" name="submit" value="login now" class="form-btn">

      <p class="form__text">
                <a class="form__link" href="signup.php" id="SIGNUP" >Want to create an account? Sign Up.</a>
            </p>
  	</div>
   </form>
</div>
</body>
</html>
