<?php $thisPage='server'; include 'sidebar.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Customers</title>
</head>
<body>
	<div class="container b-content col-sm-9">
		<div class="col-sm-6" style="border-right: solid 2px;">
		<h1>Add Customers </h1>
		<form action="" method="post" enctype="multipart/form-data">
			<label for="sname">Surname:<br><input  style="color:black" type="text" name="sname" required></label><br>
			<label for="fname">First Name:<br><input  style="color:black" type="text" name="fname" required></label><br>
			<label for="oname">Other Name:<br><input  style="color:black" type="text" name="oname"></label><br>
			<label for="gender">Gender<br>
				Male: <input type="radio" name="gender" value="Male">
				Female: <input type="radio" name="gender" value="Female">
			</label><br>
			<label for="DOB">Date of Birth: <br><input style="color:black" type="date" name="DOB"></label><br>
			<label for="email">Email Address: <br><input  style="color:black" type="email" name="email"></label><br>
			<label for="pass">Password: <br><input  style="color:black" type="password" name="pass"></label><hr>
			
			<button type="submit" name="add"value="submit" class="btn btn-custom">Add Customer</button>

		</form>
		</div>
		<div class="col-sm-6">
		<h1>Edit Customers</h1>
		<form action="" method="post">
			<select  style="color:black">
				<?php 
	                  $sql = mysqli_query($conn, "SELECT * FROM tbl_users where role_id=3");
	                    while ($row = $sql->fetch_assoc()){
	                      $choice=$row['user_ID'];
	                      echo "<option value=$choice>" . $row['firstname'] ." ". $row['surname']." ".$row['othername']. "</option>";
	                    }
	                    if($row==NULL){
                       		echo "<option value='none'>None</option>";
                    	}
	              ?>
			</select><br>
			<label for="sname">Surname:<br><input  style="color:black" type="text" name="sname" required></label><br>
			<label for="fname">First Name:<br><input  style="color:black" type="text" name="fname" required></label><br>
			<label for="oname">Other Name:<br><input  style="color:black" type="text" name="oname"></label><br>
			<label for="gender">Gender<br>
				Male: <input type="radio" name="gender" value="Male">
				Female: <input type="radio" name="gender" value="Female">
			</label><br>
			<label for="DOB">Date of Birth: <br><input  style="color:black" type="date" name="DOB"></label><br>
			<label for="email">Email Address: <br><input  style="color:black" type="email" name="email"></label><br>
			<label for="pass">Password: <br><input  style="color:black" type="password" name="pass"></label><br><hr>
			<button type="submit" name="edit" value="submit" class="btn btn-custom">Edit Customer</button><br>
		</form><br>
	</div>
	<div class="container b-content col-sm-9">
		<h1>View All Customers</h1>
		<table class="table" border="1">
			<thead style="background-color:green">
				<tr>
					<th>Name</th>
					<th>Email</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$sql = mysqli_query($conn, "SELECT * FROM tbl_users where role_id=3 and isdeleted=0");
	                while ($row = $sql->fetch_assoc()){
	                	$total=$count=0;
	                	$name=$row['firstname']." ".$row['surname']." ".$row['othername'];
	                	$c1=$row['user_id'];
	                	echo "<tr>"."<td>" .$name."</td>"."<td>" .$row['email']."</td>"."<td><form action='' method='post'><input type='hidden' value='".$c1."' name='del'><button type='submit' name='delete'  style = 'color:black'  value='delete'>Delete User</button></form></td>"."</tr>";
	                }
				?>
			</tbody>
		</table>
	</div>
</body>
</html>
<?php
if (isset($_POST['add'])) {

	$sname=$_POST['sname'];
		$fname=$_POST['fname'];
		$oname=$_POST['oname'];
		$gender=$_POST['gender'];
		$DOB=$_POST['DOB'];
		$email=$_POST['email'];
		$pass=$_POST['pass'];

		$password=md5('$pass');

			$sql=mysqli_query($conn, "INSERT INTO `tbl_users`(`surname`,`firstname`,`othername`,`gender`,`dob`,`email`,`password`,`profile_pic`,`role_id`) VALUES ('$sname','$fname','$oname','$gender','$DOB','$email','$pass','$profile',3)");
			if ($sql) {
				echo '<script>alert("Records Inserted")"</script>';
			}
			else{
				echo '<script>alert("Update Failed"'.$conn->error.')</script>';
			}
}
elseif (isset($_POST['delete'])) {
	$id=$_POST['del'];
	$sql=mysqli_query($conn, "UPDATE `tbl_users` SET `isdeleted`=1 where user_id=$id;");
	if ($sql) {
		echo "User Deleted";
	}
	else{
		echo $conn->error;
	}
}
?>