<?php include 'connection.php';session_start();
$id=$_SESSION['user_details']['user_id'];?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: black;
      color: green;
     
    }
   
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
    body{
      /* background-color: #ffe4c4; */
      background-image: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)), url(grocery.jpg);
      color:white;
    }
    body .col-sm-9 h2{
      text-align: centered;
    }
    .b-content{
      border-style: solid;
      border-color: green;
      border-width: 2px;
      padding: 15px;
    }
    .btn-custom{
      background-color: green;
      color: #FFEBC1;
    }
    #container {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
    }
  </style>
  <script src="https://cdn.anychart.com/releases/8.8.0/js/anychart-base.min.js"></script>
  <script src="https://cdn.anychart.com/releases/8.8.0/js/anychart-data-adapter.min.js"></script>
</head>
<body>

  <div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <h3 style="color: white">goGrocerygo</h3>
      <ul class="nav nav-pills nav-stacked">
      	<li <?php if ($thisPage=="dash"){echo "class='active'";}?>><a href="dashboard.php" style="color: #FFEBC1">Dashboard</a></li>
        <li <?php if ($thisPage=="server"){echo "class='active'";}?>><a href="servers.php" style="color: #FFEBC1">Customers</a></li>
        <li <?php if ($thisPage=="food"){ echo "class='active'" ;}?>><a href="food.php" style="color: #FFEBC1">Grocery Settings</a></li>
        <li><a href="../logout.php" style="color: #FFEBC1">Log Out</a></li>
      </ul><br>
    </div>