<?php
$thisPage='food';
	include 'sidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Groceries</title>
</head>
<body>
	<div class="col-sm-9 b-content">
		<h2 style="text-align: center;">Categories</h2>
		<table style="width=100%; border=1; border-style:groove; border-color:white;" class="table">
			<thead>
				<th>Category Name</th>
				<th>Update Name</th>
				<th>Delete Category</th>
			</thead>
		<?php $sql=mysqli_query($conn, "SELECT * FROM `tbl_foodcategories` WHERE isdeleted=0");
			while ($row = $sql->fetch_assoc()){
			echo "<form action='' method='post'><tr>"."<td><input type='text' name='name' style='color:black' value='" . $row['category_name']."' placeholder='". $row['category_name']."'></td>"."<td>" ."<button class='btn btn-custom' value='".$row['category_id']."' name='update' >Update Item</button>"."</td>"."<td>" ."<button class='btn btn-danger' value='".$row['category_id']."' name='delete'>Delete Item</button>"."</td>"."</tr></form>";
				}
			echo "<form action='' method='post'><tr><td colspan='2'><input type='text' class='form-control' name='name' placeholder='Add Category'></td><td><button class='btn btn-custom' value='1' name='add'>Add Category</button></td></tr></form>";
		?>
		</table>
	<!-- </div> -->
<?php
	if (isset($_POST['update'])) {
		$name=$_POST['name'];
		$id=$_POST['update'];

		$sql=mysqli_query($conn, "UPDATE `tbl_foodcategories` set `category_name`='$name' where category_id=$id ");
	}
	elseif (isset($_POST['delete'])) {
		$id=$_POST['delete'];

		$sql=mysqli_query($conn, "UPDATE `tbl_foodcategories` set `isdeleted`=1 where category_id=$id");
		$sql2=mysqli_query($conn, "UPDATE `tbl_food` set `isdeleted`=1 where food_category=$id");
	}
	elseif (isset($_POST['add'])) {
		$name=$_POST['name'];

		$sql=mysqli_query($conn, "INSERT into `tbl_foodcategories`(`category_name`,`isdeleted`) VALUES ('$name',0)");
	}
?>
	<!-- <div class="col-sm-9 b-content"> -->
		<h2 style="text-align: center;">Grocery Inventory Settings</h2>
		<!-- <h1 style="text-align: center">Edit Food Items</h1> -->
		<table style="width=100%; border=1; border-style:groove; border-color:white;" class="table">
			<thead style="background-color:green">
				<th>Grocery Name</th>
				<th>Quantity</th>
				<th>Buying Price</th>
				<th>Selling Price</th>
				<th>Update Price</th>
				<th>Delete Item</th>
			</thead>
		<?php $sql=mysqli_query($conn, "SELECT * FROM `tbl_food` WHERE isdeleted=0");
			while ($row = $sql->fetch_assoc()){
			echo "<form action='categories.php' method='post'><tr>"."<td>" . $row['food_name']."</td>"."<td><input type='number' name='quantity'  style = 'color:black' value='" . $row['quantity']."'</td>"."<td><input type='number' name='bPrice'  style = 'color:black' value='" . $row['food_buyingprice']."'</td>"."<td><input type='number' name='sPrice'  style = 'color:black' value='" . $row['food_sellingprice']."'</td>"."<td>" ."<button class='btn btn-custom' value='".$row['food_id']."' name='update' >Update Item</button>"."</td>"."<td>" ."<button class='btn btn-danger' value='".$row['food_id']."' name='delete' >Delete Item</button>"."</td>"."</tr></form>";
				}
		?>
		<div style="text-align: center; border-style: double;border-color: white; color: white">
		<h1>Add Grocery Items</h1>
		<form method="post" action="food.php" >
			<label for="name">Grocery Name:<input type="text" name="name" style="color: black"></label><br>
			<label for="choice">Category: </label><select name="choice" style="color: black">

				<?php $sql = mysqli_query($conn, "SELECT * FROM tbl_foodcategories where isdeleted=0");
	                while ($row = $sql->fetch_assoc()){
	                $choice=$row['category_id'];
	                echo "<option value=$choice>" . $row['category_id'] .".". $row['category_name']. "</option>";
	            }?>
	        </select><br>
			<label for="sPrice">Selling Price:<input type="number" name="sPrice"style="color: black" min=0></label><br>
			<label for="bPrice">Buying Price:<input type="number" name="bPrice"style="color: black" min=0></label><br>
			<label for="quantity">Quantity in grams:<input type="number" name="quantity"style="color: black" min=0></label><br>
			<button class="btn btn-primary" name="add" style="background-color:green" value=<?php echo '$choice'; ?>>Add Item</button>
		</form>
	</div>
	</div>

</body>
</html>
