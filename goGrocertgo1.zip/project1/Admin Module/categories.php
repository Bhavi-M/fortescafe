<?php
include '../connection.php';
session_start();
$id=$_SESSION['user_details']['user_id'];
	if (isset($_POST['delete'])) {
		$id=$_POST['delete'];
		$sql=mysqli_query($conn, "UPDATE `tbl_food` SET `isdeleted`=1 where food_id=$id;");
	}
	if (isset($_POST['update'])) {
		$quantity=$_POST['quantity'];
		$bPrice=$_POST['bPrice'];
		$sPrice=$_POST['sPrice'];
		$id=$_POST['update'];
		$day=date('y-m-d h:i:s');

		$sql=mysqli_query($conn, "UPDATE `tbl_food` SET `quantity`='$quantity', `food_buyingprice`='$bPrice', `food_sellingprice`='$sPrice',`updated_on`='$day' where food_id=$id;");
		
	}
	if (isset($_POST['add'])) {
		$name=$_POST['name'];
		$quantity=$_POST['quantity'];
		$bPrice=$_POST['bPrice'];
		$sPrice=$_POST['sPrice'];
		$day=date('y-m-d h:i:s');
		$choice=$_POST['choice'];

		$sql=mysqli_query($conn, "INSERT INTO `tbl_food`(`food_id`, `food_name`, `food_image`, `created_on`, `updated_on`, `food_category`, `food_buyingprice`, `food_sellingprice`, `admin_id`, `quantity`, `isdeleted`) VALUES (NULL,'$name','0','$day','$day','$choice','$bPrice','$sPrice','$id','$quantity','0')");
		if($sql){
			echo "Good Job";
			header('location:food.php');
		}
		else{
			echo '<script>alert("'.$conn->error.'")</script>';
		}
	}
?>