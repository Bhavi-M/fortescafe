<?php
$thisPage="update";
include 'sidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Data</title>
</head>
<body>
	<div class="row"><center>
	<h2 style="text-align:left">Alter your personal details here: </h2>
		<div class="col-sm-6 b-content">
	  		<form method="post" action="">
	  		<label>Surname:<br><input type="text" name="sname" class="form-control" <?php echo 'value="'.$_SESSION['user_details']['surname'].'"'?>></label><br>
	  		<label>First Name:<br><input type="text" name="fname" class="form-control" <?php echo 'value="'.$_SESSION['user_details']['firstname'].'"'?>></label><br>
	  		<label>Other Name:<br><input type="text" name="oname" class="form-control" <?php echo 'value="'.$_SESSION['user_details']['othername'].'"'?>></label><br><br>
			<label>Email Address:<br><input type="email" name="email" class="form-control" <?php echo 'value="'.$_SESSION['user_details']['email'].'"'?>></label>

	  		<button type= "submit" name="sub" class="btn btn-custom" width="50%" > SUBMIT</button>
	  		</form>
	  		<?php
	  		if (isset($_POST['sub'])){
	  			$sname=$_POST["sname"];
    			$fname=$_POST["fname"];
    			$oname=$_POST["oname"];
    			$email=$_POST["email"];
			
   				$sql = "update tbl_users set surname='$sname', firstname='$fname', othername='$oname', email=
   				'$email' where user_id=$id";
			
    			if ($conn->query($sql) === TRUE) {
      			echo "Records updated.";
    			} else {
      			echo "Error: ".$sql."<br>".$conn->error;
    			}
			
    			$conn->close();
			}  
	  		?>
            </form>
		</div></center>
	  </div>
</body>
</html>