<?php include 'connection.php';
session_start();
$id=$_SESSION['user_details']['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: black;
      color: green;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }
    body{
      background-image: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)), url(grocery.jpg);
      color:white;
    }
    .b-content{
      border-style: solid;
      border-color: green;
      border-width: 2px;
      padding: 15px;
    }
    .btn-custom{
      background-color: green;
      color: #FFEBC1;
    }
  </style>
</head>
<body>

  <div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <h3 style="color: white">goGrocerygo</h3>
      <ul class="nav nav-pills nav-stacked">
        <li <?php if ($thisPage=="home"){echo "class='active'";}?>><a href="home.php" style="color: #FFEBC1">Home</a></li>
        <li <?php if ($thisPage=="update"){ echo "class='active'" ;}?>><a href="update.php" style="color: #FFEBC1">My Details</a></li>
        <li <?php if ($thisPage=="order"){ echo "class='active'" ;}?>><a href="orders.php" style="color: #FFEBC1">Orders</a></li>
        <li <?php if ($thisPage=="rate"){echo "class='active'" ;}?>><a href="service ratings.php" style="color: #FFEBC1">Service Ratings</a></li><hr>
        <li><a href="../logout.php" style="color: #FFEBC1">Log Out</a></li>
      </ul><br>
    </div>