<?php
$thisPage="rate";
include 'sidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Rate My Server</title>
</head>
<body>
	<div class="col-sm-9" style="text-align: center;">
		<h1>Rate our service here:</h1><br>
		<form action="" method="post">
        <div class="col-sm-12 b-content">
				<div class="col-sm-6 b-content">
				<label for="Rating">What would you rate your experience here?<input type="Number" name="rate" min="1" max="10" placeholder="/10" required class="form-control"></label></div>
				<div class="col-sm-6 b-content">
				<label>Any comments?<br><textarea name="review" rows="4" cols="50%" class="form-control"></textarea></label><br></div><br>

				<button type="submit" name="sub" value="1" class="btn btn-lg btn-custom">Submit Rating</button></form>
<?php
	if (isset($_POST['sub'])) {
		$rating=$_POST['rate'];
		$review=$_POST['review'];

		$sql=mysqli_query($conn, "INSERT INTO `tbl_ratings`(`ratingsID`, `ratingAmount`, `ratingDetails`, `user_ID`) VALUES (NULL,'$rating','$review','$id')");
		if($sql){
			echo "<script>alert('Rating Successfully received. Thank you!')</script>";
		}
		else{
			echo "<script>alert(':-(')</script>";
		}
	}
?>
			
		<div>
		</div>
</body>
</html>