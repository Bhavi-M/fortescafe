<?php

$thisPage="home";
include 'sidebar.php';

?>
<!DOCTYPE html>
<html lang="en"> 
    <head>
	<title>HomePage</title>
</head>
<body>
	<div class="container-fluid col-sm-9-b-content" style="text-align: center;">
				<h1>Welcome, dear Customer.</h1><hr>
				<h2>Items ordered and stock available:</h2>
				<table class="table">
				  <thead class="thead-dark" style = "background-color:green">
				    <tr>
				      <th scope="col">Order ID</th>
				      <th scope="col">Grocery Item</th>
				      <th scope="col">Quantity</th>
				      <th scope="col">Price</th>
				    </tr>
				  </thead>
				  <tbody style = "background-color:white; color:black; text-align: left">
				  	<?php 
						$sql=mysqli_query($conn, "SELECT * from tbl_order inner join tbl_orderdetails on tbl_orderdetails.order_id=tbl_order.order_id inner JOIN tbl_food ON tbl_food.food_id=tbl_orderdetails.food_id where tbl_order.customer_id='$id'");
							while ($row = $sql->fetch_assoc()){
                      			echo "<tr>" .'<th scope="row">'. $row['order_id'] .'</th>'.'<td>'. $row['food_name'] .'</td>'.'<td>'.$row['quantity'].'</td>'.'<td>'.$row['price'].'</td>'."</tr>";
                    		}	
					?>
				</tbody>
			</table>
		</div>
</body>
</html>