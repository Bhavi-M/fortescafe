<?php
	$thisPage='home';
	include 'sidebar.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
</head>
<body>
	<div class="col-sm-9 b-content">
		<h1>View All Orders</h1>
		<table class="table" border="1"> <thead style="background-color:green"><tr><th>Name</th><th>Grocery</th><th>Quantity</th><th>Order Created:</th><th>Order Updated:</th><th>Order Total</th><th>Order Status</th></tr></thead>
		<?php $sql=mysqli_query($conn, "SELECT * FROM tbl_order inner join tbl_orderdetails on tbl_order.order_id=tbl_orderdetails.order_id inner join tbl_users on tbl_users.user_id=tbl_order.customer_id");
			while ($row=$sql->fetch_assoc()) {
				$name=$row['firstname']." ".$row['surname']." ".$row['othername'];
				echo "<tr><td>".$name."</td><td>".$row['food']."</td><td>".$row['quantity']."</td><td>".$row['created_on']."</td><td>".$row['updated_on']."</td><td>".$row['order_total']."</td><td>".$row['order_status']."</td></tr>";
			}
		?>
		
		</table>
	</div>
</body>
</html>