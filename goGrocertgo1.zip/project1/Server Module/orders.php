<?php
  $thisPage='order';
  include 'sidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>View Orders</title>
</head>
<body>
    <div class="col-sm-9 b-content">
      <h1>Make an Order:</h1>
      <form action="" method="post">
        <label for="buyer">Choose an employee:<br><select name="buyer" class="form-control">
        <?php 
                    $sql = mysqli_query($conn, "SELECT * FROM tbl_users where role_id=3 and isdeleted!=1");
                      while ($row = $sql->fetch_assoc()){
                        echo "<option value='".$row['user_id']."'>" . $row['firstname'] ." ". $row['surname']." ".$row['othername']. "</option>";
                      }
                ?>
      </select></label>
      <label for="food">Grocery Item:<br><select name="food" class="form-control">
        <?php 
                    $sql = mysqli_query($conn, "SELECT * FROM tbl_food where quantity>0 and isdeleted!=1");
                      while ($row = $sql->fetch_assoc()){
                        $choice2=$row['food_id'];
                        echo "<option value=$choice2>" . $row['food_name']. "</option>";
                      }
                ?>
      </select></label>
      <label for="quantity">Quantity<input type="number" name="quantity" min="0" max="100" class="form-control"></label>
      <button class="btn btn-custom btn-lg" type="submit" name="order">Order Now</button>
      </form>
    </div>
    <div class="col-sm-9 b-content">
      <h1>Pending Orders</h1>
    <table class="table" style= "border:1"> <thead style= "background-color:green"><tr><th>order</th><th>Grocery</th><th>Quantity</th><th>Order Created:</th><th>Order Updated:</th><th>Order Total</th></tr></thead>
    <?php $sql=mysqli_query($conn, "SELECT * FROM tbl_order inner join tbl_orderdetails on tbl_order.order_id=tbl_orderdetails.order_id inner join tbl_users on tbl_users.user_id=tbl_order.customer_id where order_status='Unpaid'");
      while ($row=$sql->fetch_assoc()) {
        echo "<tr><form action='' method='post'><td>".$row['order_id']."</td><td>".$row['food']."</td><td>".$row['quantity']."</td><td>".$row['created_on']."</td><td>".$row['updated_on']."</td><td>".$row['order_total']."</td><input type='hidden' name='id' value='".$row['user_id']."'><input type='hidden' name='total' value='".$row['order_total'].">'</form></tr>";
      }
    ?>
    
    </table>
    </div>
</body>
</html>
<?php
    if (isset($_POST['order'])) {
      $quantity=$_POST['quantity'];
      $foodID=$_POST['food'];
      $date=date('Y-m-d H:i:s');

      $sl=mysqli_query($conn, "SELECT * FROM tbl_food where food_id=$foodID");
      while ($row=$sl->fetch_assoc()) {
        $cost=$row['food_sellingprice'];
        $food=$row['food_name'];
      }
      $total=$quantity*$cost;
      $sql=mysqli_query($conn,"INSERT INTO `tbl_order`(`order_id`, `customer_id`, `server_id`, `created_on`, `updated_on`, `order_total`, `order_status`, `isdeleted`) VALUES (NULL,'','','$date','$date','$total','Unpaid','0')");
      if ($sql) {
        $sql1=mysqli_query($conn, "SELECT order_id from tbl_order");
        while ($row2=$sql1->fetch_assoc()) {
          $order=$row2['order_id'];
        }
        $sql2=mysqli_query($conn, "INSERT INTO `tbl_orderdetails`(`orderdetails_id`, `food`, `food_id`, `quantity`, `price`, `order_id`, `created_on`, `isdeleted`) VALUES (NULL,'$food','$foodID','$quantity','$cost','$order','$date','0')");
        if ($sql2) {
          echo "<script>alert('Successfull')</script>";
        }
        else{
          echo $conn->error;
        }
      }
      else{
        echo $conn->error;
      }
    }
if (isset($_POST['update'])) {
  $status=$_POST['status'];
  $order_id=$_POST['update'];
  $user=$_POST['id'];
  $date=date('Y-m-d H:i:s');
  $total=$_POST['total'];
  echo $user;
  
  $sql1=mysqli_query($conn, "SELECT * from tbd_wallet where user_id=$user");
        while ($row2=$sql1->fetch_assoc()) {
          $total1=$row2['amount'];
        }
        if ($total1>$total) {
          $total2=$total1-$total;
          $sql=mysqli_query($conn, "UPDATE `tbl_order` SET `updated_on`='$date',`order_status`='$status' WHERE order_id=$order_id");
          if ($sql) {
            $sql=mysqli_query($conn, "UPDATE `tbd_wallet` SET `amount`='$total2' WHERE `user_id`='$user'");
            if ($sql) {
             echo "<script>alert('Success :)')</script>";
            }
            else{
              echo "<script>alert('".$conn->error."')</script>";
            }
           
          }
        }
        else{
            echo "<script>alert('Account balance insufficient, please top up')</script>";
        }
  
}
?>