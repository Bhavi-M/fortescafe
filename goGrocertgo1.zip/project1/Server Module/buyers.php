<?php
  $thisPage='buyer';
  include 'sidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Buyers</title>
</head>
<body>
  <div class="col-sm-9 b-content">
    <h1>Add Buyers Here</h1>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="col-sm-6 b-content">
      <label for="sname">Surname:<br><input type="text" name="sname" required></label><br>
      <label for="fname">First Name:<br><input type="text" name="fname" required></label><br>
      <label for="oname">Other Name:<br><input type="text" name="oname"></label><br>
      <label for="gender">Gender<br>
        Male: <input type="radio" name="gender" value="Male">
        Female: <input type="radio" name="gender" value="Female">
      </label><br>
      <label for="DOB">Date of Birth: <br><input type="date" name="DOB"></label><br>
      <label for="email">Email Address: <br><input type="email" name="email"></label><br>
      <label for="pass">Password: <br><input type="password" name="pass"></label><br>

      <label for="bal">Initial Account Balance: <br><input type="number" name="bal" value="0"></label><br>
      </div>
      <div class="col-sm-6 b-content">
      <!-- <h2>Insert Profile Picture</h2>
      <input type="file" name="profile1"><br> -->
      <button type="submit" name="add"value="submit" class="btn btn-custom">Add Server</button>
      </div>
    </form>
  </div>
</body>
</html>
<?php
if (isset($_POST['add'])) {

  $sname=$_POST['sname'];
    $fname=$_POST['fname'];
    $oname=$_POST['oname'];
    $gender=$_POST['gender'];
    $DOB=$_POST['DOB'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $bal=$_POST['bal'];
    $date=date('Y-m-d h:i:s');

    $password=md5('$pass');

    $target_dir = "../Uploads/";
      $target_file = $target_dir . basename($_FILES["profile1"]["name"]);
      $uploadOk = 1;
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      
      // Check if image file is a actual image or fake image
      if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["profile1"]["tmp_name"]);
        if($check !== false) {
          echo "File is an image - " . $check["mime"] . ".";
          $uploadOk = 1;
        } else {
          echo "File is not an image.";
          $uploadOk = 0;
        }
      }
      
      // Check if file already exists
      if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
      }
      
      // Check file size
      if ($_FILES["profile1"]["size"] > 15000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
      }
      
      // Allow certain file formats
      if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
      && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
      }
      
      // Check if $uploadOk is set to 0 by an error
      if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
      // if everything is ok, try to upload file
      } 
      else {
          $profile=$_FILES["profile1"]["name"];
        }

      $sql=mysqli_query($conn, "INSERT INTO `tbl_users`(`surname`,`firstname`,`othername`,`gender`,`dob`,`email`,`password`,`profile_pic`,`role_id`) VALUES ('$sname','$fname','$oname','$gender','$DOB','$email','$pass','$profile',3)");
      if ($sql) {
        echo "<script>alert('Records Inserted')</script>";
        $sql1=mysqli_query($conn, "SELECT user_id from tbl_users");
        while ($row2=$sql1->fetch_assoc()) {
          $user=$row2['user_id'];
        }
        $sql=mysqli_query($conn, "INSERT INTO `tbd_wallet`(`wallet_id`, `user_id`, `amount`, `created_on`, `isdeleted`) VALUES (NULL,'$user','$bal','$date','0')");
      }
      else{
        echo '<script>alert("Update Failed"'.$conn->error.')</script>';
      }
}
?>