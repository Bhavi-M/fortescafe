<?php
include 'connection.php';

if(isset($_POST['submit'])){

   $sname = mysqli_real_escape_string($conn, $_POST['surname']);
   $fname = mysqli_real_escape_string($conn, $_POST['firstname']);
   $oname = mysqli_real_escape_string($conn, $_POST['othername']);
   $gender = $_POST['gender'];
   $dob =  $_POST['dob'];
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $role = $_POST['role_id'];

   $password=md5($pass);
   $cpass=md5($cpass);
   $select = " SELECT * FROM tbl_users WHERE email = '$email' && password = '$password' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exists!';

   }else{

         $insert = "INSERT INTO tbl_users ( `surname`, `firstname`, `othername`, `gender`, `dob`, `email`, `password`, `role_id`, `isdeleted`) VALUES ('$sname', '$fname', '$oname', '$gender', '$dob', '$email','$pass','$role','0')";
         mysqli_query($conn, $insert);
         header('location:login.php');
   }

};
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register form</title>
   <style>
    body{
    margin:0;
    padding: 0;
    background-image: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)), url(grocery.jpg);
}
body .reg h1{
    color: white;
    margin-top: 7%;
    margin-bottom: 3%;
}
body h2{
    color: white;
    margin-top: 3%;
    margin-bottom: 2%;
}
body .logins{
    color:white;
    text-align: center;
}
body .logins .form-btn{
    color:black;
    width: 17%;
    background-color: green;
}
form{
    color:white;
    text-align: center;
}
input[type=submit]{
    width: 17%;
    padding:5px;
    background-color: green;
    color:black
}
body .logins input[type=text]{
    color:black;
    text-align: center;
}
body .logins input[type=email]{
    color:black;
    text-align: center;
}
body .logins input[type=password]{
    color:black;
    text-align: center;
}
</style>
</head>
<body>
<div class="form-container">

   <form action="" method="post">
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
              <h2>Register</h2>
              <form method="post" action="index.php">
                <label for="surname">Surname:</label><br>
                <input type="text" class="input-box" name="surname" required><br><br>
                <label for="firstname">Firstname:</label><br>
                <input type="text" class="input-box" name="firstname" required><br><br>
                <label for="othername">Othername:</label><br>
                <input type="text" class="input-box" name="othername" optional><br><br>
                <label for="gender"><b>Gender:</b></label><br>
                <input type="radio" id="gender" name="gender" value="female">
                <label for="female">Female</label>
                <input type="radio" id="gender" name="gender"  value="male">
                <label for="male">Male</label><br><br>
                <label for="dob"><b>Date of Birth:</b></label><br>
                <input type="date" id="dob" name="dob" required><br><br>
                <label for="email">Email Address</label><br>
               <input type="email" class="input-box" id="email" name="email" required><br><br>
               <label for="password">Password</label><br>
               <input type="password" class="input-box" id="password" name="password" required><br><br><br>
               <label for="cpassword">Confirm Password</label><br>
               <input type="password" name="cpassword" required placeholder="confirm your password"><br><br>
               <!-- <label for="role"><b>Role:</b></label><br> -->
                <input type="radio" id="role" name="role_id" value="3">
                <label for="user">I am a customer</label><br><br>
                <!-- <input type="radio" id="role" name="role_id"  value="2">
                <label for="server">Employee</label><br><br> -->
               <input type="submit" name="submit" value="register now" class="form-btn">
               <p>already have an account? <a href="login.php">login now</a></p>
              </form>
</body>
</html>
