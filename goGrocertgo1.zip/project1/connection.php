<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $db = "cafe";
  
  // Create connection
  $conn = mysqli_connect($servername, $username, $password, $db);
  
  // Check connection
  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }

  function getData($sql_select,$conn){
		$result = mysqli_query($conn,$sql_select);
		$all_details = array();
		while($row = mysqli_fetch_assoc($result)){
			array_push($all_details,$row);
		}
		return $all_details;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>